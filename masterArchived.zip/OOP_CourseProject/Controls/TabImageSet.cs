﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_CourseProject.Controls
{
    // another comment because i need more commits
    // is that another pointless comment? no way!
    public class TabImageSet
    {
        public string ActiveImage { get; set; }
        public string InactiveImage { get; set; }
    }

}
