﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;


namespace OOP_CourseProject.Controls.SendPackageControls
{
    /// <summary>
    /// Interaction logic for LocationsInfo.xaml
    /// </summary>
    public partial class LocationsInfo : UserControl
    {
        public LocationsInfo()
        {
            InitializeComponent();
        }
    }
}
