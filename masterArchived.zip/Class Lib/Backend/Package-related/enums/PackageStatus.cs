﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Lib.Backend.Package_related.enums
{
    public enum PackageStatus
    {
        STORED,
        IN_TRANSIT,
        RECEIVED,
        DELIVERED,
        RETURNED,
        LOST,
        CANCELED
    }
}
