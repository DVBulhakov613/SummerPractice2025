﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("OOP_CourseProject_TestProject")]
